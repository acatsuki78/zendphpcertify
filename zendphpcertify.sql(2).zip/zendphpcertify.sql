-- phpMyAdmin SQL Dump
-- version 3.3.7deb7
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Ven 11 Janvier 2013 à 12:07
-- Version du serveur: 5.5.28
-- Version de PHP: 5.3.14

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `zendphpcertify`
--

-- --------------------------------------------------------

--
-- Structure de la table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `history_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `history_temp_id` varchar(10) NOT NULL,
  `quiz_id` smallint(5) unsigned NOT NULL,
  `question_id` mediumint(8) unsigned NOT NULL,
  `user_id` smallint(5) unsigned NOT NULL,
  `history_reponse_id` int(10) unsigned NOT NULL,
  `history_order_question` tinyint(3) unsigned NOT NULL,
  `history_status` enum('valid','flag','empty') NOT NULL,
  `history_time_start_question` datetime NOT NULL,
  PRIMARY KEY (`history_id`),
  KEY `FK_history_quiz_id` (`quiz_id`),
  KEY `FK_history_question_id` (`question_id`),
  KEY `FK_history_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `history`
--


-- --------------------------------------------------------

--
-- Structure de la table `levels`
--

CREATE TABLE IF NOT EXISTS `levels` (
  `level_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `level_title` varchar(20) NOT NULL,
  PRIMARY KEY (`level_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `levels`
--

INSERT INTO `levels` (`level_id`, `level_title`) VALUES
(1, 'Facile'),
(2, 'Moyen'),
(4, 'Difficile');

-- --------------------------------------------------------

--
-- Structure de la table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `question_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `question_title` text NOT NULL,
  `question_active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `question_image` varchar(255) NOT NULL,
  `level_id` tinyint(3) unsigned NOT NULL,
  `type_id` tinyint(3) unsigned NOT NULL,
  `theme_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`question_id`),
  KEY `FK_questions_level_id` (`level_id`),
  KEY `FK_questions_type_id` (`type_id`),
  KEY `FK_questions_theme_id` (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `questions`
--


-- --------------------------------------------------------

--
-- Structure de la table `quiz`
--

CREATE TABLE IF NOT EXISTS `quiz` (
  `quiz_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `quiz_title` varchar(100) NOT NULL,
  `quiz_active` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `quiz_nbr_question` tinyint(3) unsigned NOT NULL,
  `quiz_duration` tinyint(3) unsigned NOT NULL,
  `quiz_description` varchar(255) NOT NULL,
  `level_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`quiz_id`),
  KEY `FK_quiz_level_id` (`level_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=68 ;

--
-- Contenu de la table `quiz`
--

INSERT INTO `quiz` (`quiz_id`, `quiz_title`, `quiz_active`, `quiz_nbr_question`, `quiz_duration`, `quiz_description`, `level_id`) VALUES
(59, 'titre1', 1, 50, 50, 'decription test 1', 2),
(62, 'Titre 4', 1, 70, 90, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis diam metus, euismod vitae accumsan eu, ornare eu nisi. Mauris mauris augue, interdum ac vehicula eget, placerat varius leo. Cras egestas pretium mattis. Aliquam erat volutpat. Cum sociis natoqu', 2),
(63, 'titre 6', 1, 70, 90, 'description 6', 4),
(64, 'Titre 71', 1, 71, 91, 'description 71', 1),
(65, 'Titre 8', 1, 50, 70, 'Description 8', 1),
(66, 'titre 9', 1, 9, 9, 'description 9', 1),
(67, 'test 101', 1, 70, 90, 'test 101', 4);

-- --------------------------------------------------------

--
-- Structure de la table `quiz_rel`
--

CREATE TABLE IF NOT EXISTS `quiz_rel` (
  `quizRel_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `quiz_id` smallint(5) unsigned NOT NULL,
  `theme_id` smallint(5) unsigned NOT NULL,
  `question_by_theme` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`quizRel_id`),
  KEY `quiz_id` (`quiz_id`,`theme_id`),
  KEY `FK_quizRel_theme_id` (`theme_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=81 ;

--
-- Contenu de la table `quiz_rel`
--

INSERT INTO `quiz_rel` (`quizRel_id`, `quiz_id`, `theme_id`, `question_by_theme`) VALUES
(33, 59, 1, 25),
(34, 59, 2, 25),
(40, 62, 1, 14),
(41, 62, 2, 14),
(42, 62, 3, 14),
(43, 62, 4, 14),
(44, 62, 5, 14),
(45, 63, 2, 35),
(46, 63, 3, 35),
(49, 65, 4, 25),
(50, 65, 5, 25),
(51, 66, 1, 5),
(52, 66, 5, 4),
(67, 64, 1, 71),
(79, 67, 1, 35),
(80, 67, 3, 35);

-- --------------------------------------------------------

--
-- Structure de la table `reponses`
--

CREATE TABLE IF NOT EXISTS `reponses` (
  `reponse_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reponse_text` text NOT NULL,
  `reponse_correct` tinyint(1) NOT NULL,
  `question_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`reponse_id`),
  KEY `question_id` (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `reponses`
--


-- --------------------------------------------------------

--
-- Structure de la table `stats`
--

CREATE TABLE IF NOT EXISTS `stats` (
  `stat_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `stat_date` datetime NOT NULL,
  `stat_result` tinyint(3) unsigned NOT NULL,
  `stat_elapsed_time` smallint(5) unsigned NOT NULL,
  `user_id` smallint(5) unsigned NOT NULL,
  `quiz_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`stat_id`),
  KEY `FK_stats_user_id` (`user_id`),
  KEY `FK_stats_quiz_id` (`quiz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `stats`
--


-- --------------------------------------------------------

--
-- Structure de la table `stats_themes`
--

CREATE TABLE IF NOT EXISTS `stats_themes` (
  `stat_theme_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `stat_id` mediumint(8) unsigned NOT NULL,
  `theme_id` smallint(5) unsigned NOT NULL,
  `theme_nbr_good_answer` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`stat_theme_id`),
  KEY `FK_statsThemes_stat_id` (`stat_id`),
  KEY `FK_statsThemes_theme_id` (`theme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `stats_themes`
--


-- --------------------------------------------------------

--
-- Structure de la table `themes`
--

CREATE TABLE IF NOT EXISTS `themes` (
  `theme_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `theme_title` varchar(50) NOT NULL,
  `theme_language` varchar(10) NOT NULL,
  PRIMARY KEY (`theme_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `themes`
--

INSERT INTO `themes` (`theme_id`, `theme_title`, `theme_language`) VALUES
(1, 'Sécurité', 'PHP'),
(2, 'Array', 'PHP'),
(3, 'String', 'PHP'),
(4, 'Balises', 'HTML'),
(5, 'Font', 'CSS');

-- --------------------------------------------------------

--
-- Structure de la table `types`
--

CREATE TABLE IF NOT EXISTS `types` (
  `type_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `type_title` varchar(10) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `types`
--

INSERT INTO `types` (`type_id`, `type_title`) VALUES
(1, 'select'),
(2, 'text'),
(3, 'checkbox'),
(4, 'radio');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `user_email` varchar(100) NOT NULL,
  `user_password` varchar(40) NOT NULL,
  `user_status` enum('admin','member') NOT NULL,
  `user_firstname` varchar(50) NOT NULL,
  `user_lastname` varchar(50) NOT NULL,
  `user_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `users`
--


--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `history`
--
ALTER TABLE `history`
  ADD CONSTRAINT `FK_history_question_id` FOREIGN KEY (`question_id`) REFERENCES `questions` (`question_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_history_quiz_id` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`quiz_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_history_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `FK_questions_level_id` FOREIGN KEY (`level_id`) REFERENCES `levels` (`level_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_questions_theme_id` FOREIGN KEY (`theme_id`) REFERENCES `themes` (`theme_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_questions_type_id` FOREIGN KEY (`type_id`) REFERENCES `types` (`type_id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `FK_quiz_level_id` FOREIGN KEY (`level_id`) REFERENCES `levels` (`level_id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `quiz_rel`
--
ALTER TABLE `quiz_rel`
  ADD CONSTRAINT `FK_quizRel_quiz_id` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`quiz_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_quizRel_theme_id` FOREIGN KEY (`theme_id`) REFERENCES `themes` (`theme_id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `reponses`
--
ALTER TABLE `reponses`
  ADD CONSTRAINT `FK_reponses_question_id` FOREIGN KEY (`question_id`) REFERENCES `questions` (`question_id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `stats`
--
ALTER TABLE `stats`
  ADD CONSTRAINT `FK_stats_quiz_id` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`quiz_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_stats_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `stats_themes`
--
ALTER TABLE `stats_themes`
  ADD CONSTRAINT `FK_statsThemes_stat_id` FOREIGN KEY (`stat_id`) REFERENCES `stats` (`stat_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_statsThemes_theme_id` FOREIGN KEY (`theme_id`) REFERENCES `themes` (`theme_id`) ON UPDATE CASCADE;
